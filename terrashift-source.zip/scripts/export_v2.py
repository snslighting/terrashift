"""Export real reduced research rasters for TerraShift 2.0, retaining failed validation."""

import json
from datetime import UTC, datetime
from pathlib import Path

import matplotlib
import numpy as np
from PIL import Image
from pyproj import Transformer

from terrashift.cache import digest
from terrashift.visualization import aggregate_display, referenced_candidate, summarize_values

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / "frontend/public/evidence"
out.mkdir(parents=True, exist_ok=True)
records = []
arrays = []
for index, name in enumerate(["california-expanded", "california-july-repeat"]):
    folder = ROOT / "data/processed" / name
    report = json.loads((folder / "quality-report.json").read_text())
    comparison = json.loads((folder / "gnss-comparison.json").read_text())
    with np.load(folder / "scientific-subset.npz") as archive:
        layers = {
            k: archive[k]
            for k in [
                "x",
                "y",
                "valid",
                "coherenceMagnitude",
                "connectedComponents",
                "corrected_phase_radians",
            ]
        }
    ref = next(r for r in comparison["rows"] if r["role"] == "reference")
    los = referenced_candidate(layers, ref, report["wavelength_m"])
    coh = np.where(layers["valid"], layers["coherenceMagnitude"], np.nan)
    arrays.append((layers, coh, los))
    records.append((report, comparison, ref, folder))

first, second = arrays
if not (np.array_equal(first[0]["x"], second[0]["x"]) and np.array_equal(first[0]["y"], second[0]["y"])):
    raise ValueError("Difference requires identical native grids.")
common = np.isfinite(first[1]) & np.isfinite(second[1])
difference = np.where(common, second[1] - first[1], np.nan)


def serial(values, digits=4):
    return [round(float(v), digits) if np.isfinite(v) else None for v in values.ravel()]


def image(values, path, mode):
    if mode == "coherence":
        colors = matplotlib.colormaps["viridis"](np.nan_to_num(values))
    else:
        limit = 100 if mode == "los" else 0.5
        colors = matplotlib.colormaps["RdBu_r"](np.clip((np.nan_to_num(values) + limit) / (2 * limit), 0, 1))
    colors[:, :, 3] = np.where(np.isfinite(values), 0.9, 0)
    Image.fromarray((colors * 255).astype("uint8")).save(path)


pairs = []
for index, (layers, coh, los) in enumerate(arrays):
    report, comparison, ref, folder = records[index]
    bounds, data = aggregate_display(
        layers["x"], layers["y"], report["epsg"], {"coherence": coh, "los": los, "difference": difference}
    )
    for mode in data:
        image(data[mode]["values"], out / f"{mode}-{index}.png", mode)
    tr = Transformer.from_crs(3857, 4326, always_xy=True)
    west, south = tr.transform(*bounds[:2])
    east, north = tr.transform(*bounds[2:])
    metadata = report["metadata"]
    pairs.append(
        {
            "id": index,
            "before": comparison["before"],
            "after": comparison["after"],
            "granule": report["granule"],
            "bbox": report["bbox_wgs84"],
            "count": comparison["comparison_count"],
            "rmse": comparison["rmse_mm"],
            "accepted": report["accepted_after_corrections"],
            "threshold": report["coherence_threshold"],
            "stations": comparison["rows"],
            "image": f"coherence-{index}.png",
            "los_image": f"los-{index}.png",
            "difference_image": f"difference-{index}.png",
            "coordinates": [[west, north], [east, north], [east, south], [west, south]],
            "grid": {
                "size": 256,
                "bounds_mercator": bounds,
                "values": serial(data["coherence"]["values"]),
                "los_values": serial(data["los"]["values"], 3),
                "support_counts": data["coherence"]["counts"].ravel().tolist(),
                "los_support_counts": data["los"]["counts"].ravel().tolist(),
                "common_support_counts": data["difference"]["counts"].ravel().tolist(),
            },
            "difference_values": serial(data["difference"]["values"]),
            "reference": "P287",
            "reference_phase_rad": ref["median_phase_rad"],
            "component": ref["component"],
            "science_validated": False,
            "total_uncertainty_mm": None,
            "epsg": report["epsg"],
            "wavelength_m": report["wavelength_m"],
            "metadata": {
                k: metadata[k]
                for k in [
                    "productSpecificationVersion",
                    "orbitPassDirection",
                    "productVersion",
                    "trackNumber",
                    "frameNumber",
                    "productDoi",
                ]
                if k in metadata
            }
            | {
                "processor_version": report["processor_version"],
                "correction_equation": report["correction_equation"],
                "ionosphere_policy": report["ionosphere_interpolation_policy"],
                "validation": "FAILED",
                "processing_status": "CACHED_REAL_RESEARCH",
                "los_sign": "Toward sensor is positive",
            },
            "statistics": {"coherence": summarize_values(coh), "los": summarize_values(los)},
            "source_hashes": {
                n: digest(folder / n)
                for n in ["scientific-subset.npz", "quality-report.json", "gnss-comparison.json"]
            },
        }
    )

payload = {
    "generated": datetime.now(UTC).isoformat(),
    "pairs": pairs,
    "coherence_note": "Means of accepted source-pixel centers in a 256×256 Web Mercator display grid. Not displacement.",
    "difference_note": "Second-pair minus first-pair coherence, computed on identical native pixels accepted in both products. Dimensionless; no physical-event classification.",
    "gnss_source": "https://geodesy.unr.edu/PlugNPlayPortal.php",
}
(out / "research-data.json").write_text(
    json.dumps(payload, separators=(",", ":"), allow_nan=False), encoding="utf-8"
)
print(
    json.dumps(
        {
            "pairs": len(pairs),
            "validation": "FAILED",
            "common_native_pixels": int(common.sum()),
            "bytes": (out / "research-data.json").stat().st_size,
        }
    )
)
