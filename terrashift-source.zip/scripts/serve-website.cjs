const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../website');
const types = {'.html':'text/html', '.js':'text/javascript', '.mjs':'text/javascript', '.css':'text/css', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png'};
module.exports = function serve(port=4174) {
  return http.createServer((req,res)=>{
    const name = decodeURIComponent(req.url.split('?')[0]);
    const file = path.resolve(root, '.' + (name === '/' ? '/index.html' : name));
    if (!file.startsWith(root + path.sep)) {res.writeHead(403);res.end();return;}
    fs.readFile(file, (error, data)=>{
      res.writeHead(error ? 404 : 200, {'Content-Type': types[path.extname(file)] || 'text/plain', 'Cache-Control':'no-cache'});
      res.end(error ? 'Not found' : data);
    });
  }).listen(port, '127.0.0.1');
};
if (require.main === module) module.exports();
