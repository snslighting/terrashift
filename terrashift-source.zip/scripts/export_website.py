"""Export only public research summaries and reduced coherence layers for GitHub Pages."""

import json
from pathlib import Path

import matplotlib
import numpy as np
from PIL import Image
from pyproj import Transformer
from rasterio.transform import from_bounds, from_origin
from rasterio.warp import Resampling, reproject, transform_bounds

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / "website"
out.mkdir(exist_ok=True)
pairs = []
for index, name in enumerate(["california-expanded", "california-july-repeat"]):
    folder = ROOT / "data/processed" / name
    report = json.loads((folder / "quality-report.json").read_text())
    comparison = json.loads((folder / "gnss-comparison.json").read_text())
    with np.load(folder / "scientific-subset.npz") as a:
        x, y, valid, coherence = a["x"], a["y"], a["valid"], a["coherenceMagnitude"]
    dx, dy = float(x[1] - x[0]), float(y[0] - y[1])
    bounds = (x[0] - dx / 2, y[-1] - dy / 2, x[-1] + dx / 2, y[0] + dy / 2)
    mercator = transform_bounds(report["epsg"], 3857, *bounds, densify_pts=41)
    size = 256
    target = np.full((size, size), np.nan, dtype="float32")
    reproject(
        np.where(valid, coherence, np.nan).astype("float32"),
        target,
        src_transform=from_origin(bounds[0], bounds[3], dx, dy),
        src_crs=report["epsg"],
        dst_transform=from_bounds(*mercator, size, size),
        dst_crs=3857,
        src_nodata=np.nan,
        dst_nodata=np.nan,
        resampling=Resampling.average,
    )
    colors = matplotlib.colormaps["viridis"](np.nan_to_num(target))
    colors[:, :, 3] = np.where(np.isfinite(target), 0.85, 0)
    Image.fromarray((colors * 255).astype("uint8")).save(out / f"coherence-{index}.png")
    tr = Transformer.from_crs(3857, 4326, always_xy=True)
    west, south = tr.transform(mercator[0], mercator[1])
    east, north = tr.transform(mercator[2], mercator[3])
    grid = [round(float(v), 3) if np.isfinite(v) else None for v in target.ravel()]
    pairs.append(
        {
            "id": index,
            "before": comparison["before"],
            "after": comparison["after"],
            "granule": report["granule"],
            "bbox": report["bbox_wgs84"],
            "count": comparison["comparison_count"],
            "rmse": comparison["rmse_mm"],
            "accepted": report["accepted_after_corrections"],
            "threshold": report["coherence_threshold"],
            "stations": comparison["rows"],
            "image": f"coherence-{index}.png",
            "coordinates": [[west, north], [east, north], [east, south], [west, south]],
            "grid": {"size": size, "bounds_mercator": list(mercator), "values": grid},
            "reference": "P287",
            "science_validated": False,
            "total_uncertainty_mm": None,
        }
    )
payload = {
    "generated": "2026-10-06",
    "pairs": pairs,
    "coherence_note": "Spatial averages of accepted research pixels on a 256×256 Web Mercator grid. Not displacement or total uncertainty.",
    "gnss_source": "https://geodesy.unr.edu/PlugNPlayPortal.php",
}
(out / "research-data.json").write_text(
    json.dumps(payload, separators=(",", ":"), allow_nan=False), encoding="utf-8"
)
print(f"Exported {len(pairs)} real pairs to {out}")
