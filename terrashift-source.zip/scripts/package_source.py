"""Create a deterministic, explicit-allowlist public source archive; never package caches/secrets."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "work/terrashift-source.zip"
FILES = [
    "README.md",
    "pyproject.toml",
    "uv.lock",
    ".gitignore",
    "Dockerfile",
    ".dockerignore",
    "frontend/package.json",
    "frontend/package-lock.json",
    "frontend/index.html",
    "frontend/tsconfig.json",
    "frontend/vite.config.ts",
    "frontend/.env.example",
    ".github/workflows/pages.yml",
]
DIRECTORIES = {
    "src/terrashift": {".py"},
    "scripts": {".py", ".mjs", ".cjs"},
    "tests": {".py"},
    "docs": {".md"},
    "frontend/src": {".tsx", ".ts", ".css"},
    "frontend/scripts": {".mjs"},
    "frontend/public": {".json", ".geojson", ".png", ".svg", ".mjs", ".md", ".txt"},
}
paths = [ROOT / name for name in FILES]
for folder, extensions in DIRECTORIES.items():
    paths.extend(p for p in (ROOT / folder).rglob("*") if p.is_file() and p.suffix in extensions)
paths = sorted(set(paths), key=lambda p: p.relative_to(ROOT).as_posix())
OUT.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(OUT, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in paths:
        relative = path.relative_to(ROOT).as_posix()
        if path.is_symlink() or any(word in path.parts for word in ["__pycache__", "node_modules"]):
            raise ValueError(f"Unexpected distribution path: {relative}")
        if any(word in relative.lower() for word in [".netrc", ".env.local", "cookies", ".urs_"]):
            raise ValueError(f"Forbidden distribution path: {relative}")
        info = ZipInfo(relative, date_time=(2026, 10, 8, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        archive.writestr(info, path.read_bytes())
manifest = {
    "file": OUT.name,
    "bytes": OUT.stat().st_size,
    "files": len(paths),
    "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest(),
    "paths": [p.relative_to(ROOT).as_posix() for p in paths],
}
(ROOT / "work/source-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps({k: v for k, v in manifest.items() if k != "paths"}))
