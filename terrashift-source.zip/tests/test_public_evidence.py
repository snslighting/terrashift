"""Verify shipped actual exports; passing these tests does not certify displacement."""

import json

import numpy as np
import pytest

from terrashift.config import ROOT


def test_real_export_support_units_and_failed_comparisons_are_preserved():
    research = json.loads((ROOT / "frontend/public/evidence/research-data.json").read_text())
    assert len(research["pairs"]) == 2
    for pair in research["pairs"]:
        assert pair["granule"].startswith("NISAR_L2_PR_GUNW_")
        assert pair["science_validated"] is False and pair["total_uncertainty_mm"] is None
        assert pair["metadata"]["validation"] == "FAILED"
        assert pair["metadata"]["ionosphere_policy"] == "included_for_sensitivity_only"
        grid = pair["grid"]
        assert len(grid["values"]) == grid["size"] ** 2
        assert sum(grid["support_counts"]) == pair["accepted"]
        assert sum(grid["los_support_counts"]) == pair["statistics"]["los"]["count"]
        assert sum(grid["common_support_counts"]) == 1_248_081
        for value, count in zip(grid["values"], grid["support_counts"], strict=True):
            assert (value is None) == (count == 0)
            if value is not None:
                assert 0 <= value <= 1
        rows = [s for s in pair["stations"] if s.get("residual_mm") is not None]
        assert len(rows) == pair["count"]
        assert np.sqrt(np.mean([s["residual_mm"] ** 2 for s in rows])) == pytest.approx(pair["rmse"])
        for row in rows:
            assert row["residual_mm"] == pytest.approx(
                row["relative_nisar_candidate_los_mm"] - row["relative_gnss_los_mm"]
            )
    assert research["pairs"][0]["difference_values"] == research["pairs"][1]["difference_values"]
