import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  ArrowRight,
  Check,
  MapPin,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useApp } from "../lib/context";
import { CALIFORNIA, number } from "../lib/science";
import {
  PageIntro,
  Reveal,
  StatusBadge,
  SourceLink,
  Skeleton,
  Button,
} from "../components/UI";
import { Raster } from "../components/Raster";
import { ResidualChart } from "../components/Charts";
const MapViewer = lazy(() => import("../components/MapViewer"));
const chapters = [
  [
    "01 / THE PLACE",
    "A valley, viewed from orbit.",
    "The California study covers a San Joaquin Valley AOI. It is an interferometric development case, rather than a confirmed subsidence map. Begin with the actual observations and their provenance.",
  ],
  [
    "02 / THE OBSERVATIONS",
    "Two real, repeated observations.",
    "GUNW pairs span June 29–July 11 and July 11–23, 2026. Both use descending track 042, frame 070 and the same native grid. Files were downloaded, checked against NASA size and checksum metadata, and inspected as HDF5.",
  ],
  [
    "03 / THE PROCESS",
    "Correct. Mask. Reference.",
    "The reviewed native phase equation subtracts ionosphere, wet and hydrostatic troposphere and adds the solid-Earth tide correction. The research sensitivity mask includes interpolated ionosphere. Candidates are referenced to the P287 median in one connected component.",
  ],
  [
    "04 / THE TEST",
    "Independent evidence disagrees.",
    "Exact acquisition-day GNSS changes are projected into local radar LOS. All available comparisons are kept: 12 for the first pair, 13 for the second. RMSE is 28.4 mm and 51.1 mm. Both fail the project validation milestone.",
  ],
  [
    "05 / THE FINDING",
    "A limit worth understanding.",
    "Common-pixel analysis changes station candidates by less than 0.30 mm, while a 107.25 mm reference-cancelling station discrepancy remains in pair 02. A different shared reference offset cannot make all comparisons agree. No physical cause is uniquely established.",
  ],
];
export default function Discoveries() {
  const { research } = useApp(),
    [chapter, setChapter] = useState(0),
    [pairId, setPairId] = useState(0),
    [filter, setFilter] = useState("All studies");
  const pair = research?.pairs[pairId];
  return (
    <main className="content-page discoveries-page">
      <PageIntro
        eyebrow="EARTH STORIES / FOLLOW THE EVIDENCE"
        title="A changing planet. An unfolding story."
        description="Scientific stories grounded in real observations. Explore one complete NISAR processing and validation audit, and two cases where data quality set the limit."
      />
      <div className="story-filters">
        {["All studies", "Interferometric research", "Quality audits"].map(
          (f) => (
            <button
              className={f === filter ? "active" : ""}
              key={f}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ),
        )}
      </div>
      {filter !== "Quality audits" && (
        <section id="california" className="earth-story">
          <div className="earth-story-heading">
            <div>
              <span className="story-tag">01 / CALIFORNIA, UNITED STATES</span>
              <h2>The signal and the ground.</h2>
              <p>San Joaquin Valley · 29 June–23 July 2026</p>
            </div>
            <StatusBadge status="measured_provisional" />
          </div>
          <div className="earth-story-stage">
            <div className="story-map">
              {pair ? (
                <Suspense fallback={<Skeleton />}>
                  <MapViewer
                    pair={pair}
                    selection={{ name: "San Joaquin Valley", bbox: CALIFORNIA }}
                    layer={chapter >= 2 ? "los" : "coherence"}
                    compact
                  />
                </Suspense>
              ) : (
                <Skeleton />
              )}
              <div className="story-chapter-key">
                {chapter >= 2
                  ? "PROVISIONAL LOS CANDIDATE · mm"
                  : "RADAR COHERENCE · DIMENSIONLESS"}
              </div>
            </div>
            <div className="story-narration">
              <span className="eyebrow">{chapters[chapter][0]}</span>
              <h3>{chapters[chapter][1]}</h3>
              <p>{chapters[chapter][2]}</p>
              <div className="chapter-progress">
                {chapters.map((_, i) => (
                  <button
                    aria-label={`Story chapter ${i + 1}`}
                    key={i}
                    onClick={() => setChapter(i)}
                    className={chapter === i ? "active" : ""}
                  >
                    <span>0{i + 1}</span>
                    <i />
                  </button>
                ))}
              </div>
              <div className="chapter-navigation">
                <button
                  disabled={chapter === 0}
                  onClick={() => setChapter(chapter - 1)}
                  aria-label="Previous story chapter"
                >
                  <ChevronLeft size={18} />
                </button>
                <span>{chapter + 1} OF 5</span>
                <button
                  disabled={chapter === 4}
                  onClick={() => setChapter(chapter + 1)}
                  aria-label="Next story chapter"
                >
                  <ChevronRight size={18} />
                </button>
              </div>
              <div className="story-pair-buttons">
                {research?.pairs.map((p) => (
                  <button
                    key={p.id}
                    className={pairId === p.id ? "active" : ""}
                    onClick={() => setPairId(p.id)}
                  >
                    Pair 0{p.id + 1}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="story-findings">
            <div>
              <span>PAIR 01 · RMSE</span>
              <strong>
                28.4<small> mm</small>
              </strong>
              <p>12 station comparisons</p>
            </div>
            <div>
              <span>PAIR 02 · RMSE</span>
              <strong>
                51.1<small> mm</small>
              </strong>
              <p>13 station comparisons</p>
            </div>
            <div>
              <span>COMMON-SUPPORT CHECK</span>
              <strong>
                &lt; 0.30<small> mm</small>
              </strong>
              <p>Maximum station-candidate change</p>
            </div>
            <div>
              <span>VALIDATION OUTCOME</span>
              <strong className="warning-text">Failed</strong>
              <p>Total uncertainty remains unknown</p>
            </div>
          </div>
          <div className="story-bottom">
            <p>
              This is an end-to-end scientific audit with an explicit negative
              validation outcome. It does not establish subsidence, a certified
              displacement map or a long-term trend.
            </p>
            <Link to={`/analysis?pair=${pairId}`} className="button secondary">
              Open the analysis
              <ArrowRight size={17} />
            </Link>
          </div>
          <SourceLink href="https://nisar-docs.asf.alaska.edu/gunw/">
            NISAR GUNW product documentation
          </SourceLink>
          <SourceLink href="https://geodesy.unr.edu/PlugNPlayPortal.php">
            Independent GNSS data · NGL
          </SourceLink>
        </section>
      )}
      {filter !== "Interferometric research" && (
        <div className="audit-stories">
          <Reveal className="audit-story">
            <div id="flores" className="audit-story-art flores-art">
              <span>121.53° E / 8.50° S</span>
              <MapPin />
              <small>GEOGRAPHIC CONTEXT · NO SCIENTIFIC RASTER</small>
            </div>
            <div className="audit-story-copy">
              <span className="story-tag">02 / FLORES, INDONESIA</span>
              <h2>When quality sets the limit.</h2>
              <StatusBadge status="quality_limited" />
              <p>
                The actual ascending GUNW pair covers August 12–24, 2026, on
                track 168 / frame 173. No spatially supported pixels survived
                the strict development quality policy.
              </p>
              <div className="audit-observation">
                <strong>0</strong>
                <span>
                  SUPPORTED PIXELS
                  <br />
                  STRICT QUALITY AUDIT
                </span>
              </div>
              <p>
                Event context motivates the study. It does not supply
                displacement ground truth. The available audit cannot establish
                earthquake displacement.
              </p>
              <SourceLink href="https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=NISAR_L2_GUNW_PROVISIONAL_V1&bounding_box=121.1,-8.9,121.95,-8.1&temporal=2026-08-12T00:00:00Z,2026-08-24T23:59:59Z">
                Original catalog search
              </SourceLink>
              <Link to="/explore?lat=-8.5&lon=121.53" className="text-button">
                Explore this location
                <ArrowUpRight size={16} />
              </Link>
            </div>
          </Reveal>
          <Reveal className="audit-story">
            <div id="venezuela" className="audit-story-art venezuela-art">
              <span>66.85° W / 10.40° N</span>
              <MapPin />
              <small>GEOGRAPHIC CONTEXT · NO SCIENTIFIC RASTER</small>
            </div>
            <div className="audit-story-copy">
              <span className="story-tag">03 / COASTAL VENEZUELA</span>
              <h2>
                Close on a map.
                <br />
                Far in the data.
              </h2>
              <StatusBadge status="quality_limited" />
              <p>
                The real June 13–25, 2026 acquisition pair was audited against
                the independent CCS1 GNSS station. The strict audit retained 154
                supported pixels in the study area.
              </p>
              <div className="audit-observation">
                <strong>
                  15.7<small> km</small>
                </strong>
                <span>
                  NEAREST ACCEPTED PIXEL
                  <br />
                  TO GNSS STATION CCS1
                </span>
              </div>
              <p>
                No accepted radar pixels were within 500 m of CCS1. A distant
                pixel cannot substitute for co-located validation, so no
                validated deformation claim is made.
              </p>
              <SourceLink href="https://geodesy.unr.edu/PlugNPlayPortal.php">
                NGL station data
              </SourceLink>
              <Link to="/explore?lat=10.4&lon=-66.85" className="text-button">
                Explore this location
                <ArrowUpRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      )}
      <section className="story-future">
        <h2>
          The next story begins
          <br />
          with a real observation.
        </h2>
        <p>
          Flood, glacier, agricultural and wetland interpretations require
          suitable products, tailored methods and supporting evidence. They will
          be added only when those conditions are met.
        </p>
        <Button to="/explore">Discover an observation</Button>
      </section>
    </main>
  );
}
