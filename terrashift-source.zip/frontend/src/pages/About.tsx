import { ArrowUpRight, Orbit, Globe2, ShieldCheck, Code2 } from "lucide-react";
import {
  PageIntro,
  Reveal,
  Eyebrow,
  Button,
  SourceLink,
} from "../components/UI";
export default function About() {
  return (
    <main className="content-page about-page">
      <PageIntro
        eyebrow="ABOUT TERRASHIFT / A PURPOSEFUL PERSPECTIVE"
        title="Make the changing Earth understandable."
        description="TerraShift brings radar observations, scientific context and independent evidence together—so more people can explore a planet in motion."
      />
      <section className="about-mission">
        <Reveal>
          <Eyebrow>OUR MISSION</Eyebrow>
          <h2>
            Curiosity, guided
            <br />
            by evidence.
          </h2>
        </Reveal>
        <div>
          <p>
            Surface change is easy to overlook and difficult to interpret.
            TerraShift is an independent NASA Space Apps project for the 2026{" "}
            <em>Dancing with the SARs</em> challenge: an interactive application
            using NASA–ISRO NISAR radar observations to explore surface changes
            around the world.
          </p>
          <p>
            The application combines worldwide product discovery with a
            reproducible California scientific demonstration. Its failed
            validation outcome is a central part of the story. Scientific
            usefulness includes understanding when the data cannot support a
            reliable conclusion.
          </p>
          <SourceLink href="https://www.spaceappschallenge.org/2026/challenges/dancing-with-the-sars/">
            Official NASA Space Apps challenge
          </SourceLink>
        </div>
      </section>
      <div className="about-values">
        {[
          [
            Globe2,
            "Worldwide curiosity",
            "Search beyond a handful of predefined regions and discover actual intersecting products.",
          ],
          [
            ShieldCheck,
            "Scientific honesty",
            "Preserve failed validation, actual references and unknown uncertainty.",
          ],
          [
            Orbit,
            "An accessible perspective",
            "Make maps, comparison tools and explanations understandable without hiding the science.",
          ],
        ].map(([Icon, title, text]) => (
          <Reveal className="about-value" key={String(title)}>
            {typeof Icon !== "string" && <Icon size={28} />}
            <h3>{String(title)}</h3>
            <p>{String(text)}</p>
          </Reveal>
        ))}
      </div>
      <section className="about-roadmap">
        <Eyebrow>BUILT, AND STILL BUILDING</Eyebrow>
        <h2>A clear path forward.</h2>
        <div className="roadmap-row">
          <span className="roadmap-state done">AVAILABLE</span>
          <div>
            <h3>Global discovery and transparent analysis</h3>
            <p>
              Worldwide geographic selection, public NISAR GUNW discovery,
              actual coverage footprints, two cached coherence and provisional
              LOS candidate maps, GNSS comparisons, interactive date
              comparisons, source traces and exports.
            </p>
          </div>
        </div>
        <div className="roadmap-row">
          <span className="roadmap-state available">
            IMPLEMENTED / DEPLOYMENT REQUIRED
          </span>
          <div>
            <h3>Separate scientific API</h3>
            <p>
              Python FastAPI services for bounded discovery, product metadata,
              cached raster access, persistent cached-region jobs and exports.
              The public frontend uses direct public services while a hosted
              backend is not configured.
            </p>
          </div>
        </div>
        <div className="roadmap-row">
          <span className="roadmap-state next">RESEARCH REQUIRED</span>
          <div>
            <h3>Resolve the displacement-validation gap</h3>
            <p>
              Independent processing cross-check, stable reference evidence,
              unwrapping and correction review, a defensible total uncertainty
              model and held-out validation. The two sequential development
              pairs do not support a calibrated time series.
            </p>
          </div>
        </div>
        <div className="roadmap-row">
          <span className="roadmap-state next">FUTURE CAPABILITY</span>
          <div>
            <h3>Global processing and additional change modes</h3>
            <p>
              Authenticated acquisition workers, operational raster tiles and
              compute capacity for selected global products. Add backscatter,
              flooding, glacier or agricultural stories only with tailored
              methods and independently supported interpretation.
            </p>
          </div>
        </div>
      </section>
      <section className="about-stack">
        <Eyebrow>OPEN TECHNOLOGY</Eyebrow>
        <h2>Built to be inspected.</h2>
        <div className="stack-pills">
          {[
            "React",
            "TypeScript",
            "Vite",
            "MapLibre",
            "Three.js",
            "Motion",
            "FastAPI",
            "Python",
            "H5py",
            "Rasterio",
            "NumPy",
            "SciPy",
            "PyProj",
          ].map((t) => (
            <span key={t}>{t}</span>
          ))}
        </div>
        <p>
          Source code and deployment documentation are available in the project
          repository. Team-member names and affiliations have not been supplied;
          no institutional endorsement is implied.
        </p>
        <SourceLink href="https://github.com/snslighting/terrashift">
          Explore the source code
        </SourceLink>
      </section>
      <section className="about-cta">
        <h2>
          The next perspective
          <br />
          is yours.
        </h2>
        <Button to="/explore">Explore the Earth</Button>
      </section>
    </main>
  );
}
