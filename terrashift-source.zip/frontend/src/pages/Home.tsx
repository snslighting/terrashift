import { lazy, Suspense, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  motion,
  useScroll,
  useTransform,
  useReducedMotion,
} from "motion/react";
import {
  ArrowUpRight,
  ArrowDown,
  Satellite,
  ScanLine,
  Orbit,
  Globe2,
  Check,
  Layers3,
  MoveUpRight,
  Radio,
  ChevronRight,
} from "lucide-react";
import { Button, Eyebrow, Reveal, SourceLink } from "../components/UI";
import { useApp } from "../lib/context";
import { Raster } from "../components/Raster";
const Globe = lazy(() => import("../components/Globe"));
export default function Home() {
  const navigate = useNavigate(),
    { research } = useApp(),
    hero = useRef<HTMLDivElement>(null),
    { scrollYProgress } = useScroll({
      target: hero,
      offset: ["start start", "end start"],
    }),
    reduced = useReducedMotion(),
    y = useTransform(scrollYProgress, [0, 1], [0, reduced ? 0 : 130]);
  return (
    <main className="home-page">
      <section className="hero" ref={hero}>
        <div className="hero-grid" />
        <motion.div className="hero-earth" style={{ y }}>
          <Suspense
            fallback={
              <div className="globe-loading">
                <Globe2 className="spin" size={80} />
              </div>
            }
          >
            <Globe
              onSelect={(lon, lat) =>
                navigate(`/explore?lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`)
              }
            />
          </Suspense>
        </motion.div>
        <div className="hero-copy">
          <motion.div
            initial={reduced ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <Eyebrow>NASA–ISRO NISAR / EARTH OBSERVATION</Eyebrow>
          </motion.div>
          <h1>
            {["The Earth", "is moving.", "Now you can", "see it."].map(
              (line, i) => (
                <motion.span
                  key={line}
                  initial={reduced ? false : { opacity: 0, y: 35 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.75,
                    delay: 0.08 + i * 0.085,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className={i > 1 ? "hero-light" : ""}
                >
                  {line}
                </motion.span>
              ),
            )}
          </h1>
          <motion.p
            initial={reduced ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
          >
            A new perspective on a changing planet.
            <br />
            Explore real radar observations, compare the evidence,
            <br className="desktop-break" /> and uncover the stories beneath the
            surface.
          </motion.p>
          <motion.div
            className="hero-actions"
            initial={reduced ? false : { opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.65 }}
          >
            <Button to="/explore">Explore the Earth</Button>
            <Button to="/science" secondary>
              Discover the science
            </Button>
          </motion.div>
          <div className="hero-proof">
            <span className="live-dot" />
            REAL OBSERVATIONS. TRANSPARENT SCIENCE.
            <span className="preview-label">RESEARCH PREVIEW</span>
          </div>
        </div>
        <div className="hero-bottom">
          <a href="#perspective" className="scroll-cue">
            <ArrowDown size={15} />
            SCROLL TO DISCOVER
          </a>
          <span>ONE PLANET. COUNTLESS PERSPECTIVES.</span>
          <div>
            <span>01 — 07</span>
            <i />
            <i />
            <i />
          </div>
        </div>
      </section>
      <div className="mission-strip">
        <span>POWERED BY EARTH OBSERVATION</span>
        <strong>
          NASA <small>×</small> ISRO
        </strong>
        <strong>
          NISAR <small>L-BAND SAR</small>
        </strong>
        <strong>
          ASF <small>DATA SERVICES</small>
        </strong>
        <strong>
          NGL <small>INDEPENDENT GNSS</small>
        </strong>
        <SourceLink href="https://www.spaceappschallenge.org/2026/challenges/dancing-with-the-sars/">
          SPACE APPS 2026
        </SourceLink>
      </div>
      <section id="perspective" className="home-section perspective-section">
        <Reveal>
          <Eyebrow>01 / A DIFFERENT WAY TO SEE</Eyebrow>
          <h2>
            Some of the biggest changes
            <br />
            begin <em>out of sight.</em>
          </h2>
        </Reveal>
        <div className="perspective-content">
          <Reveal className="perspective-text">
            <p>
              The ground beneath a city can settle. A glacier can shift. A
              landscape can change long before the story becomes visible from
              above.
            </p>
            <p>
              Radar observations help us ask better questions about those
              changes. TerraShift brings the observations, their quality, and
              independent evidence into one place.
            </p>
            <Link to="/discoveries" className="text-button">
              Meet the changing Earth
              <ArrowUpRight size={16} />
            </Link>
          </Reveal>
          <div className="impact-cards">
            {[
              [
                Layers3,
                "Land & infrastructure",
                "Investigate displacement estimates with a defined spatial reference.",
              ],
              [
                Orbit,
                "Dynamic landscapes",
                "Explore radar signal quality through time, with its physical limits.",
              ],
              [
                Globe2,
                "A global perspective",
                "Find real acquisitions anywhere a suitable product is available.",
              ],
            ].map(([Icon, title, text], i) => (
              <Reveal
                key={String(title)}
                className="impact-card"
                delay={i * 0.1}
              >
                {typeof Icon !== "string" && <Icon size={24} />}
                <span>0{i + 1}</span>
                <h3>{String(title)}</h3>
                <p>{String(text)}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="radar-story home-section">
        <div className="radar-visual">
          <div className="radar-orbit" />
          <Satellite size={44} className="radar-satellite" />
          <div className="radar-beam b1" />
          <div className="radar-beam b2" />
          <div className="radar-ground">
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
          <span className="diagram-tag tag-satellite">01 / TRANSMIT</span>
          <span className="diagram-tag tag-ground">02 / LISTEN</span>
          <span className="radar-caption">
            CONCEPTUAL DIAGRAM · NOT A MEASUREMENT
          </span>
        </div>
        <Reveal className="radar-copy">
          <Eyebrow>02 / A SIGNAL THROUGH THE NOISE</Eyebrow>
          <h2>
            See through clouds.
            <br />
            <em>Listen to the Earth.</em>
          </h2>
          <p>
            NISAR sends radar pulses and records their echoes. Repeated
            observations capture phase, signal strength and coherence—different
            clues that require different methods.
          </p>
          <div className="radar-facts">
            <div>
              <Radio size={18} />
              <span>
                Active radar<small>Day and night observations</small>
              </span>
            </div>
            <div>
              <ScanLine size={18} />
              <span>
                Repeat observations
                <small>Compare actual acquisition pairs</small>
              </span>
            </div>
            <div>
              <Check size={18} />
              <span>
                Independent evidence<small>Test candidates against GNSS</small>
              </span>
            </div>
          </div>
          <Button to="/science" secondary>
            How the science works
          </Button>
        </Reveal>
      </section>
      <section className="home-section featured-section">
        <div className="section-heading">
          <Reveal>
            <Eyebrow>03 / EARTH STORIES</Eyebrow>
            <h2>
              Every observation
              <br />
              has a story.
            </h2>
          </Reveal>
          <Reveal>
            <p>
              Real data. Open questions.
              <br />
              Follow the evidence from orbit to the ground.
            </p>
            <Link to="/discoveries" className="text-button">
              Explore Earth Stories
              <ArrowUpRight size={16} />
            </Link>
          </Reveal>
        </div>
        <Reveal className="feature-story">
          <Link to="/discoveries#california" className="feature-story-image">
            {research ? (
              <Raster pair={research.pairs[0]} />
            ) : (
              <div className="case-mini-art" />
            )}
            <div className="feature-grid-lines" />
            <span className="image-coordinate">36.50° N / 120.35° W</span>
            <span className="image-key">
              REAL NISAR COHERENCE · DIMENSIONLESS
            </span>
            <div className="image-focus">
              <i />
              <span>SAN JOAQUIN VALLEY</span>
            </div>
            <span className="image-arrow">
              <ArrowUpRight />
            </span>
          </Link>
          <div className="feature-story-copy">
            <span className="story-tag">CALIFORNIA, UNITED STATES</span>
            <h3>
              The signal
              <br />
              and the ground.
            </h3>
            <p>
              Two real radar pairs. A network of independent GNSS stations. A
              study of what the available evidence can—and cannot—establish.
            </p>
            <div className="feature-metrics">
              <div>
                <strong>02</strong>
                <span>REAL ACQUISITION PAIRS</span>
              </div>
              <div>
                <strong>12 / 13</strong>
                <span>GNSS COMPARISONS</span>
              </div>
            </div>
            <div className="story-outcome">
              <i />
              Validation failed · scientific audit
            </div>
            <Link to="/discoveries#california" className="text-button">
              Follow the evidence
              <ArrowRightIcon />
            </Link>
          </div>
        </Reveal>
        <div className="home-small-stories">
          <Link to="/discoveries#flores">
            <span>INDONESIA / FLORES ISLAND</span>
            <h3>When quality sets the limit.</h3>
            <p>A strict mask leaves no supported research pixels.</p>
            <ArrowUpRight />
          </Link>
          <Link to="/discoveries#venezuela">
            <span>VENEZUELA / CARACAS REGION</span>
            <h3>Close on a map. Far in the data.</h3>
            <p>Why 15.7 km cannot replace a co-located comparison.</p>
            <ArrowUpRight />
          </Link>
        </div>
      </section>
      <section className="home-section world-callout">
        <Reveal>
          <Eyebrow>04 / YOUR NEXT PERSPECTIVE</Eyebrow>
          <h2>
            Where will
            <br />
            you look <em>next?</em>
          </h2>
          <p>
            Search any location. Discover the real observations.
            <br />
            Let the evidence tell you what is available.
          </p>
          <Button to="/explore">Open the worldwide explorer</Button>
        </Reveal>
        <div className="world-callout-art">
          <Globe2 />
          <div className="coordinate-card">
            <span className="live-dot" />
            NASA CMR · PUBLIC CATALOG
            <small>
              Coverage footprints come from actual product metadata.
            </small>
          </div>
          <span className="orbit-coord">GLOBAL DISCOVERY / LOCAL EVIDENCE</span>
        </div>
      </section>
      <section className="credibility-strip">
        <Reveal>
          <Eyebrow>SCIENCE YOU CAN INSPECT</Eyebrow>
          <h3>
            A beautiful map should come
            <br />
            with an honest explanation.
          </h3>
        </Reveal>
        <div>
          <p>
            Every research result retains its dates, product identifier,
            reference, units and validation outcome. Missing observations stay
            missing. Unknown uncertainty stays unknown.
          </p>
          <Link to="/data" className="text-button">
            Read the methodology
            <ArrowUpRight size={16} />
          </Link>
        </div>
      </section>
    </main>
  );
}
function ArrowRightIcon() {
  return <ChevronRight size={17} />;
}
