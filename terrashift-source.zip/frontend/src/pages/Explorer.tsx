import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import {
  Search,
  ArrowRight,
  ChevronDown,
  Download,
  CalendarDays,
  Satellite,
  MapPin,
  X,
  HelpCircle,
  RefreshCw,
  ExternalLink,
  LocateFixed,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";
import {
  discover,
  searchPlaces,
  requestProcessing,
  getJob,
  backendConfigured,
} from "../lib/api";
import {
  CALIFORNIA,
  number,
  signed,
  pointBBox,
  downloadJSON,
  regionalStats,
  validBBox,
} from "../lib/science";
import { useApp } from "../lib/context";
import type {
  BBox,
  Discovery,
  Layer,
  Pixel,
  Place,
  Product,
  Selection,
  Station,
} from "../lib/types";
import { StatusBadge, Empty, SourceLink, Skeleton } from "../components/UI";
const MapViewer = lazy(() => import("../components/MapViewer"));
export default function Explorer() {
  const { research, selection, setSelection, error: researchError } = useApp();
  const [params] = useSearchParams(),
    [query, setQuery] = useState(""),
    [places, setPlaces] = useState<Place[]>([]),
    [searching, setSearching] = useState(false),
    [loading, setLoading] = useState(false),
    [error, setError] = useState(""),
    [result, setResult] = useState<Discovery>(),
    [product, setProduct] = useState<Product>(),
    [pairId, setPairId] = useState<number | null>(null),
    [layer, setLayer] = useState<Layer>("coherence"),
    [basemap, setBasemap] = useState<"satellite" | "terrain" | "geographic">(
      "satellite",
    ),
    [quality, setQuality] = useState(0),
    [opacity, setOpacity] = useState(0.8),
    [stations, setStations] = useState(true),
    [start, setStart] = useState("2026-01-01"),
    [end, setEnd] = useState(new Date().toISOString().slice(0, 10)),
    [pixel, setPixel] = useState<Pixel>(),
    [station, setStation] = useState<Station>(),
    [collapsed, setCollapsed] = useState(false),
    [tour, setTour] = useState<number | null>(null),
    [job, setJob] = useState<{
      status: string;
      message: string;
      job_id?: string;
      result?: unknown;
    }>(),
    [boundsOpen, setBoundsOpen] = useState(false),
    [bounds, setBounds] = useState("");
  const controller = useRef<AbortController>(null),
    searchController = useRef<AbortController>(null);
  const tourDialog = useRef<HTMLElement>(null);
  const tourIsOpen = tour !== null;
  useEffect(() => {
    if (!tourIsOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const dialog = tourDialog.current;
    const focusable = () => [
      ...(dialog?.querySelectorAll<HTMLButtonElement>(
        "button:not(:disabled)",
      ) ?? []),
    ];
    focusable()[0]?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setTour(null);
      if (event.key !== "Tab") return;
      const nodes = focusable(),
        first = nodes[0],
        last = nodes.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      previous?.focus();
    };
  }, [tourIsOpen]);
  const pair = pairId == null ? undefined : research?.pairs[pairId];
  useEffect(() => {
    const lat = params.get("lat"),
      lon = params.get("lon");
    if (
      lat !== null &&
      lon !== null &&
      Number.isFinite(+lat) &&
      Number.isFinite(+lon) &&
      Math.abs(+lat) <= 90 &&
      Math.abs(+lon) <= 180
    )
      choose({ name: `${+lat}°, ${+lon}°`, bbox: pointBBox(+lon, +lat) });
    if (params.get("study") === "california") openCached(0);
  }, []);
  useEffect(
    () => () => {
      controller.current?.abort();
      searchController.current?.abort();
    },
    [],
  );
  useEffect(() => {
    if (!job?.job_id || !["queued", "running"].includes(job.status)) return;
    const timer = setTimeout(() => {
      getJob(job.job_id!)
        .then((p) => setJob({ ...p, job_id: job.job_id }))
        .catch((e) => setJob({ status: "failed", message: e.message }));
    }, 1500);
    return () => clearTimeout(timer);
  }, [job]);
  function choose(s: Selection) {
    controller.current?.abort();
    searchController.current?.abort();
    setSearching(false);
    setLoading(false);
    setSelection(s);
    setResult(undefined);
    setProduct(undefined);
    setPairId(null);
    setPixel(undefined);
    setStation(undefined);
    setPlaces([]);
    setError("");
    setJob(undefined);
    setBounds(s.bbox.map((v) => v.toFixed(4)).join(", "));
  }
  function openCached(id: number) {
    const s = { name: "San Joaquin Valley, California", bbox: CALIFORNIA };
    choose(s);
    setPairId(id);
    setLayer("coherence");
  }
  async function search(e: React.FormEvent) {
    e.preventDefault();
    searchController.current?.abort();
    const c = new AbortController();
    searchController.current = c;
    setSearching(true);
    setError("");
    setPlaces([]);
    try {
      const p = await searchPlaces(query, c.signal);
      if (c.signal.aborted) return;
      if (p.length === 1) {
        const v = p[0];
        choose({ name: v.name, bbox: pointBBox(v.longitude, v.latitude) });
      } else {
        setPlaces(p);
        if (!p.length)
          setError(
            "No matching place. Try a nearby city or latitude, longitude.",
          );
      }
    } catch (e) {
      if (!c.signal.aborted) setError((e as Error).message);
    } finally {
      if (!c.signal.aborted) setSearching(false);
    }
  }
  async function find() {
    if (!selection) return;
    controller.current?.abort();
    const c = new AbortController();
    controller.current = c;
    setLoading(true);
    setError("");
    setResult(undefined);
    setProduct(undefined);
    setPairId(null);
    setPixel(undefined);
    setStation(undefined);
    setJob(undefined);
    try {
      const d = await discover(selection, start, end, c.signal);
      if (!c.signal.aborted) setResult(d);
    } catch (e) {
      if (!c.signal.aborted) setError((e as Error).message);
    } finally {
      if (!c.signal.aborted) setLoading(false);
    }
  }
  function selectProduct(p: Product) {
    setProduct(p);
    setPairId(p.cached_pair);
    setPixel(undefined);
    setStation(undefined);
    setJob(undefined);
  }
  const exportData = () =>
    downloadJSON("terrashift-research-evidence.json", {
      project: "TerraShift",
      status: pair
        ? "MEASURED_PROVISIONAL_VALIDATION_FAILED"
        : product
          ? "PROCESSING_UNAVAILABLE"
          : "CATALOG_DISCOVERY",
      science_validated: false,
      total_uncertainty_mm: null,
      selection,
      discovery: result,
      product,
      pair,
      pixel,
      station,
      job,
      exported_utc: new Date().toISOString(),
      note: "Cached raster statistics and pixel samples describe reduced display cells. Coherence is not displacement.",
    });
  const summary =
    pair && selection
      ? regionalStats(
          pair.grid,
          selection.bbox,
          layer === "los" ? "los" : "coherence",
          selection.polygon,
        )
      : null;
  const tours = [
    [
      "Choose a place",
      "Search a city, address or landmark, or enter latitude, longitude. Click the map or draw a rectangle/polygon to choose your area.",
    ],
    [
      "Discover real observations",
      "Set a date range and search NASA CMR. Footprints describe acquisition coverage, not the presence of valid ground-motion measurements.",
    ],
    [
      "Inspect the evidence",
      "A product with a cached result opens its real coherence or provisional LOS candidate. Other products show metadata and processing availability.",
    ],
    [
      "Compare responsibly",
      "Open Analysis for date comparisons, quality and GNSS residuals. Read the validation outcome before drawing a conclusion.",
    ],
  ];
  return (
    <main className={`explorer-page ${collapsed ? "panel-collapsed" : ""}`}>
      <aside className="explorer-panel">
        <div className="panel-top">
          <div className="eyebrow">
            <span />
            WORLDWIDE EXPLORER
          </div>
          <button
            onClick={() => setCollapsed(true)}
            aria-label="Collapse search panel"
          >
            <PanelLeftClose size={18} />
          </button>
        </div>
        <h1>Find your perspective.</h1>
        <p className="muted">
          Discover the observations behind a changing planet.
        </p>
        <form className="search-field" onSubmit={search}>
          <Search size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="City, address, or lat, lon…"
            aria-label="Search anywhere on Earth"
          />
          <button aria-label="Search locations" disabled={searching}>
            {searching ? (
              <RefreshCw size={17} className="spin" />
            ) : (
              <ArrowRight size={17} />
            )}
          </button>
        </form>
        <span className="tiny">Search on submit · Photon / OpenStreetMap</span>
        {places.length > 0 && (
          <div className="place-results">
            {places.map((p, i) => (
              <button
                key={i}
                onClick={() =>
                  choose({
                    name: p.name,
                    bbox: pointBBox(p.longitude, p.latitude),
                  })
                }
              >
                <MapPin size={14} />
                <span>
                  {p.name}
                  <small>
                    {p.latitude.toFixed(4)}, {p.longitude.toFixed(4)}
                  </small>
                </span>
                <ArrowRight size={14} />
              </button>
            ))}
          </div>
        )}
        <div className="selection-heading">
          <span>SELECTED AREA</span>
          <button onClick={() => setBoundsOpen(!boundsOpen)}>
            Edit bounds
            <ChevronDown size={13} />
          </button>
        </div>
        {selection ? (
          <div className="selected-place">
            <LocateFixed size={17} />
            <div>
              <strong>{selection.name}</strong>
              <small>
                {selection.bbox.map((v) => v.toFixed(3)).join(" · ")}
              </small>
            </div>
            <button
              onClick={() => {
                controller.current?.abort();
                searchController.current?.abort();
                setLoading(false);
                setSearching(false);
                setSelection(undefined);
                setPairId(null);
                setResult(undefined);
                setProduct(undefined);
                setJob(undefined);
                setPixel(undefined);
                setStation(undefined);
              }}
              aria-label="Clear selection"
            >
              <X size={14} />
            </button>
          </div>
        ) : (
          <p className="selection-empty">
            Search a place or select an area on the map.
          </p>
        )}
        {boundsOpen && (
          <form
            className="bounds-form"
            onSubmit={(e) => {
              e.preventDefault();
              const b = bounds.split(",").map(Number) as BBox;
              if (b.length !== 4 || !validBBox(b)) {
                setError(
                  "Enter west, south, east, north in WGS84. West > east represents a dateline crossing.",
                );
                return;
              }
              choose({ name: "Custom WGS84 area", bbox: b });
            }}
          >
            <label>
              West, south, east, north
              <input
                value={bounds}
                onChange={(e) => setBounds(e.target.value)}
                placeholder="−120.99, 36.005, −119.7, 36.99"
              />
            </label>
            <button className="text-button">Apply region</button>
          </form>
        )}
        <div className="date-fields">
          <label>
            <CalendarDays size={13} />
            From
            <input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
            />
          </label>
          <label>
            To
            <input
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              max={new Date().toISOString().slice(0, 10)}
            />
          </label>
        </div>
        <button
          className="button discover-button"
          onClick={find}
          disabled={!selection || loading}
        >
          {loading ? (
            <RefreshCw size={17} className="spin" />
          ) : (
            <Satellite size={17} />
          )}{" "}
          {loading ? "Querying NASA CMR…" : "Discover NISAR observations"}
          <ArrowRight size={16} />
        </button>
        <p className="tiny">
          GUNW provisional collection · up to 50 results.
          <br />
          Catalog availability does not establish measurement quality.
        </p>
        {error && (
          <div className="error-box" role="alert">
            {error}
            <button onClick={() => setError("")} aria-label="Dismiss error">
              <X size={13} />
            </button>
          </div>
        )}
        {researchError && (
          <div className="error-box">
            Cached evidence could not load. Worldwide catalog discovery is still
            available.
          </div>
        )}
        {loading && (
          <Skeleton label="Looking for intersecting NISAR products…" />
        )}
        {result && (
          <div className="catalog-results">
            <div className="section-caption">
              <span>{result.returned} PRODUCTS RETURNED</span>
              <span>{result.bounded ? "BOUNDED SEARCH" : "NASA CMR"}</span>
            </div>
            {!result.returned ? (
              <Empty title="No suitable GUNW data">
                No products were returned for this area and date range. Try a
                broader period or a nearby region. Other NISAR product types are
                not searched here.
              </Empty>
            ) : (
              result.products.map((p) => (
                <button
                  key={p.id}
                  className={`product-card ${p.id === product?.id ? "active" : ""}`}
                  onClick={() => selectProduct(p)}
                >
                  <span className="product-dates">
                    {p.before?.slice(0, 10) ?? "Unknown"}
                    <ArrowRight size={13} />
                    {p.after?.slice(0, 10) ?? "Unknown"}
                  </span>
                  <span className="product-detail">
                    TRACK {p.track ?? "?"} · FRAME {p.frame ?? "?"} ·{" "}
                    {p.orbit?.toLowerCase() ?? "unknown orbit"}
                  </span>
                  <span className="product-bottom">
                    <span
                      className={`data-pill ${p.cached_pair != null ? "cached" : ""}`}
                    >
                      {p.cached_pair != null
                        ? "Cached research result"
                        : "Metadata · processing required"}
                    </span>
                    <ArrowRight size={15} />
                  </span>
                </button>
              ))
            )}
            <p className="tiny">
              Queried {new Date(result.queried_utc).toLocaleString()} ·{" "}
              {result.cached ? "5-minute cache" : "public metadata"}
              {result.hits != null
                ? ` · ${result.hits.toLocaleString()} catalog matches`
                : ""}
              .
            </p>
          </div>
        )}
        {!result && !loading && (
          <div className="quick-start">
            <div className="section-caption">START WITH REAL EVIDENCE</div>
            <button className="featured-study" onClick={() => openCached(0)}>
              <span className="case-mini-art">
                <i />
                <i />
                <i />
              </span>
              <span>
                <strong>San Joaquin Valley</strong>
                <small>2 real pairs · GNSS validation audit</small>
              </span>
              <ArrowRight size={17} />
            </button>
            <div className="global-places">
              {[
                ["Tashkent", 69.24, 41.3],
                ["Jakarta", 106.85, -6.21],
                ["Reykjavík", -21.94, 64.15],
              ].map(([n, lon, lat]) => (
                <button
                  key={n}
                  onClick={() =>
                    choose({
                      name: String(n),
                      bbox: pointBBox(Number(lon), Number(lat)),
                    })
                  }
                >
                  {n}
                  <ArrowRight size={12} />
                </button>
              ))}
            </div>
            <p className="tiny">
              These shortcuts select coordinates. Product availability is
              discovered live.
            </p>
          </div>
        )}
        <div className="panel-bottom">
          <span className="live-dot" />
          {backendConfigured
            ? "API CONNECTED · PUBLIC METADATA"
            : "DIRECT PUBLIC CATALOG · CACHED SCIENCE"}
          <button onClick={() => setTour(0)}>
            <HelpCircle size={15} />
            Take a tour
          </button>
        </div>
      </aside>
      <section className="explorer-map-area">
        {collapsed && (
          <button className="reopen-panel" onClick={() => setCollapsed(false)}>
            <PanelLeftOpen size={18} />
            Search & discovery
          </button>
        )}
        <div className="map-controls-top">
          <select
            aria-label="Basemap"
            value={basemap}
            onChange={(e) => setBasemap(e.target.value as typeof basemap)}
          >
            <option value="satellite">Satellite</option>
            <option value="geographic">Geographic</option>
            <option value="terrain">Terrain</option>
          </select>
          <button onClick={exportData} aria-label="Export evidence">
            <Download size={15} />
            <span>Export evidence</span>
          </button>
          <button onClick={() => setTour(0)} aria-label="Explorer tour">
            <HelpCircle size={16} />
          </button>
        </div>
        <Suspense fallback={<Skeleton label="Preparing interactive map…" />}>
          <MapViewer
            pair={pair}
            layer={layer}
            selection={selection}
            products={result?.products}
            basemap={basemap}
            opacity={opacity}
            quality={quality}
            showStations={stations}
            onSelect={choose}
            onProduct={(id) => {
              const p = result?.products.find((p) => p.id === id);
              if (p) selectProduct(p);
            }}
            onPixel={(p) => {
              setPixel(p);
              setStation(undefined);
            }}
            onStation={(s) => {
              setStation(s);
              setPixel(undefined);
            }}
          />
        </Suspense>
        {pair && (
          <div className="layer-panel">
            <div className="section-caption">MEASUREMENT LAYERS</div>
            <div className="segmented">
              <button
                className={layer === "coherence" ? "active" : ""}
                onClick={() => setLayer("coherence")}
              >
                Coherence
              </button>
              <button
                className={layer === "los" ? "active" : ""}
                onClick={() => setLayer("los")}
              >
                LOS candidate
              </button>
            </div>
            <label className="range-label">
              Layer opacity<span>{Math.round(opacity * 100)}%</span>
              <input
                type="range"
                min="0"
                max="1"
                step=".05"
                value={opacity}
                onChange={(e) => setOpacity(+e.target.value)}
                aria-label="Layer opacity"
              />
            </label>
            <label className="range-label">
              Display-cell coherence filter<span>≥ {quality.toFixed(2)}</span>
              <input
                type="range"
                min="0"
                max="1"
                step=".05"
                value={quality}
                onChange={(e) => setQuality(+e.target.value)}
                aria-label="Display-cell coherence filter"
              />
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                checked={stations}
                onChange={(e) => setStations(e.target.checked)}
              />
              GNSS stations
            </label>
          </div>
        )}
        {(pair || product) && (
          <div className="map-result-panel">
            <button
              className="close-result"
              onClick={() => {
                setPairId(null);
                setProduct(undefined);
              }}
              aria-label="Close result"
            >
              <X size={16} />
            </button>
            <span className="eyebrow">
              <span />
              {station
                ? "GNSS STATION"
                : pixel
                  ? "PIXEL INSPECTION"
                  : "OBSERVATION EVIDENCE"}
            </span>
            {pair ? (
              <>
                <h2>
                  {station
                    ? station.station
                    : pixel
                      ? "A closer look."
                      : "San Joaquin Valley"}
                </h2>
                <StatusBadge status="measured_provisional" />
                <div className="result-date">
                  {pair.before} → {pair.after}
                </div>
                {station ? (
                  <>
                    <div className="result-value">
                      {signed(station.relative_nisar_candidate_los_mm)}
                      <small>mm · LOS candidate</small>
                    </div>
                    <dl>
                      <dt>Relative GNSS</dt>
                      <dd>{signed(station.relative_gnss_los_mm)} mm</dd>
                      <dt>Residual</dt>
                      <dd>{signed(station.residual_mm)} mm</dd>
                      <dt>Median coherence</dt>
                      <dd>{number(station.median_coherence, 3)}</dd>
                      <dt>Support within 500 m</dt>
                      <dd>{station.accepted_within_500m ?? 0} pixels</dd>
                      <dt>GNSS formal σ</dt>
                      <dd>{number(station.gnss_formal_sigma_mm)} mm</dd>
                    </dl>
                    {station.unavailable_reason && (
                      <p className="warning">{station.unavailable_reason}</p>
                    )}
                    {station.role === "reference" && (
                      <p className="tiny">
                        P287 defines zero for the radar comparison. Its GNSS LOS
                        change is {signed(station.gnss_los_mm)} mm; stability is
                        unverified.
                      </p>
                    )}
                  </>
                ) : pixel ? (
                  <>
                    <div className="result-value">
                      {layer === "los"
                        ? signed(pixel.los)
                        : number(pixel.coherence, 3)}
                      <small>
                        {layer === "los"
                          ? "mm · provisional LOS"
                          : "coherence · dimensionless"}
                      </small>
                    </div>
                    <dl>
                      <dt>Coordinates</dt>
                      <dd>
                        {pixel.latitude.toFixed(5)},{" "}
                        {pixel.longitude.toFixed(5)}
                      </dd>
                      <dt>Coherence</dt>
                      <dd>{number(pixel.coherence, 3)}</dd>
                      <dt>Accepted source pixels</dt>
                      <dd>
                        {layer === "los" ? pixel.losSupport : pixel.support}
                      </dd>
                      <dt>Reference</dt>
                      <dd>P287 · component {pair.component}</dd>
                    </dl>
                    {pixel.coherence == null && (
                      <p className="warning">
                        No accepted research pixels in this display cell.
                      </p>
                    )}
                  </>
                ) : (
                  <>
                    <div className="result-value">
                      {number(pair.rmse)}
                      <small>mm · GNSS comparison RMSE</small>
                    </div>
                    <p className="tiny">
                      All {pair.count} station comparisons retained. Validation
                      failed.
                    </p>
                    {summary && (
                      <dl>
                        <dt>Selected display cells</dt>
                        <dd>{summary.count.toLocaleString()}</dd>
                        <dt>
                          Mean {layer === "los" ? "LOS candidate" : "coherence"}
                        </dt>
                        <dd>
                          {number(summary.mean, layer === "los" ? 1 : 3)}
                          {layer === "los" ? " mm" : ""}
                        </dd>
                      </dl>
                    )}
                  </>
                )}
                <div className="warning compact">
                  Validation failed. Includes interpolated ionosphere for
                  sensitivity research. Total displacement uncertainty is
                  unknown.
                </div>
                <div className="pair-selector">
                  {research?.pairs.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setPairId(p.id);
                        setPixel(undefined);
                        setStation(undefined);
                      }}
                      className={pairId === p.id ? "active" : ""}
                    >
                      Pair {p.id + 1}
                      <small>
                        {p.before.slice(5)} → {p.after.slice(5)}
                      </small>
                    </button>
                  ))}
                </div>
                <Link className="text-button" to={`/analysis?pair=${pairId}`}>
                  Open detailed analysis
                  <ArrowRight size={15} />
                </Link>
                <SourceLink
                  href={`https://cmr.earthdata.nasa.gov/search/granules.umm_json?granule_ur=${encodeURIComponent(pair.granule)}`}
                >
                  Original product metadata
                </SourceLink>
              </>
            ) : (
              product && (
                <>
                  <h2>Product discovered.</h2>
                  <StatusBadge status="processing_unavailable" />
                  <div className="result-date">
                    {product.before?.slice(0, 10) ?? "Unknown date"} →{" "}
                    {product.after?.slice(0, 10) ?? "Unknown date"}
                  </div>
                  <p className="tiny">
                    The footprint confirms catalog coverage. Scientific quality
                    requires inspecting the actual product.
                  </p>
                  <dl>
                    <dt>Track / frame</dt>
                    <dd>
                      {product.track} / {product.frame}
                    </dd>
                    <dt>Orbit</dt>
                    <dd>{product.orbit}</dd>
                    <dt>Product</dt>
                    <dd>GUNW · provisional</dd>
                    <dt>Scientific result</dt>
                    <dd>Not processed</dd>
                  </dl>
                  <code className="granule-id">{product.granule}</code>
                  {product.metadata_warnings.length > 0 && (
                    <p className="warning">
                      {product.metadata_warnings.join(" ")}
                    </p>
                  )}
                  <button
                    className="text-button"
                    onClick={async () => {
                      if (!selection) return;
                      setJob({
                        status: "checking",
                        message: "Checking processing availability…",
                      });
                      try {
                        setJob(await requestProcessing(product, selection));
                      } catch (e) {
                        setJob({
                          status: "failed",
                          message: (e as Error).message,
                        });
                      }
                    }}
                  >
                    <Satellite size={15} />
                    Check processing availability
                  </button>
                  {job && (
                    <div className="warning compact" role="status">
                      <strong>{job.status.replaceAll("_", " ")}</strong>
                      <p>{job.message}</p>
                    </div>
                  )}
                  <SourceLink href={product.source_url}>
                    View original metadata
                  </SourceLink>
                  <SourceLink href="https://search.asf.alaska.edu/#/?dataset=NISAR">
                    Open ASF data search
                  </SourceLink>
                  <p className="tiny">
                    Science-file downloads can require Earthdata sign-in.
                    Credentials are never entered into TerraShift.
                  </p>
                </>
              )
            )}
          </div>
        )}
      </section>
      {tour !== null && (
        <div className="modal-backdrop" onClick={() => setTour(null)}>
          <section
            ref={tourDialog}
            className="tour-dialog"
            role="dialog"
            aria-modal="true"
            aria-label="Explorer introduction"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setTour(null)}
              className="dialog-x"
              aria-label="Close tour"
            >
              <X size={18} />
            </button>
            <div className="eyebrow">EXPLORER GUIDE · {tour + 1} / 4</div>
            <h2>{tours[tour][0]}</h2>
            <p>{tours[tour][1]}</p>
            <div className="tour-progress">
              {tours.map((_, i) => (
                <i key={i} className={i <= tour ? "active" : ""} />
              ))}
            </div>
            <button
              autoFocus
              className="button"
              onClick={() => setTour(tour === 3 ? null : tour + 1)}
            >
              {tour === 3 ? "Start exploring" : "Next step"}
              <ArrowRight size={17} />
            </button>
          </section>
        </div>
      )}
    </main>
  );
}
