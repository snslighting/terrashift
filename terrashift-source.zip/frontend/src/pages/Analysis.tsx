import { lazy, Suspense, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowRight,
  Download,
  Play,
  Pause,
  Columns2,
  ArrowLeftRight,
  ChartNoAxesCombined,
  Layers,
  Info,
} from "lucide-react";
import { useApp } from "../lib/context";
import {
  number,
  signed,
  CALIFORNIA,
  downloadJSON,
  downloadCSV,
  stats,
} from "../lib/science";
import type { Layer, Pixel, Station } from "../lib/types";
import {
  PageIntro,
  StatusBadge,
  Skeleton,
  Empty,
  SourceLink,
} from "../components/UI";
import { Legend, Raster } from "../components/Raster";
import { ResidualChart, TemporalChart } from "../components/Charts";
const MapViewer = lazy(() => import("../components/MapViewer"));
export default function Analysis() {
  const { research, error, selection } = useApp(),
    [params] = useSearchParams();
  const [pairId, setPairId] = useState(params.get("pair") === "1" ? 1 : 0),
    [layer, setLayer] = useState<Layer>("coherence"),
    [mode, setMode] = useState<"swipe" | "side" | "difference" | "temporal">(
      "swipe",
    ),
    [swipe, setSwipe] = useState(50),
    [playing, setPlaying] = useState(false),
    [station, setStation] = useState("P298"),
    [pixel, setPixel] = useState<Pixel>(),
    [quality, setQuality] = useState(0);
  useEffect(() => {
    setPixel(undefined);
  }, [pairId]);
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => setPairId((v) => (v === 0 ? 1 : 0)), 2200);
    return () => clearInterval(timer);
  }, [playing]);
  if (!research)
    return (
      <main className="content-page">
        <PageIntro
          eyebrow="SCIENTIFIC WORKSPACE"
          title="Look beneath the surface."
          description="Compare real radar observations and inspect the evidence behind each result."
        />
        {error ? (
          <Empty title="Evidence unavailable">{error}</Empty>
        ) : (
          <Skeleton />
        )}
      </main>
    );
  const pair = research.pairs[pairId],
    comparison = pair.stations.find((s) => s.station === station);
  const exportCSV = () =>
    downloadCSV("terrashift-station-comparisons.csv", [
      [
        "granule",
        "before",
        "after",
        "station",
        "radar_candidate_los_mm",
        "relative_gnss_los_mm",
        "residual_mm",
        "validation",
        "reference",
      ],
      ...pair.stations.map((s) => [
        pair.granule,
        pair.before,
        pair.after,
        s.station,
        s.relative_nisar_candidate_los_mm,
        s.relative_gnss_los_mm,
        s.residual_mm,
        "FAILED",
        "P287",
      ]),
    ]);
  const exportJSON = () =>
    downloadJSON("terrashift-analysis.json", {
      project: "TerraShift",
      pair,
      selected_pixel: pixel,
      selected_station: comparison,
      validation: "FAILED",
      total_uncertainty_mm: null,
      display_filter_min_coherence: quality,
      source: research.gnss_source,
      exported_utc: new Date().toISOString(),
    });
  return (
    <main className="content-page analysis-page">
      <div className="analysis-heading">
        <PageIntro
          eyebrow="SCIENTIFIC WORKSPACE / CALIFORNIA"
          title="Look beneath the surface."
          description="Two real NISAR pairs. Independent GNSS. A complete view of the evidence, including where the measurements disagree."
        />
        <div className="analysis-exports">
          <button className="button secondary" onClick={exportJSON}>
            <Download size={15} />
            Evidence JSON
          </button>
          <button className="text-button" onClick={exportCSV}>
            Station CSV
            <Download size={13} />
          </button>
        </div>
      </div>
      {selection && selection.name !== "San Joaquin Valley, California" && (
        <div className="info-banner">
          <Info size={18} />
          <div>
            Your explorer selection: <strong>{selection.name}</strong>. This
            workspace currently provides cached scientific results for the
            California AOI.{" "}
            <Link to="/explore">Return to global discovery.</Link>
          </div>
        </div>
      )}
      <section className="analysis-summary">
        <div>
          <StatusBadge status="measured_provisional" />
          <h2>San Joaquin Valley</h2>
          <p>
            California, United States · descending orbit · track 042 / frame 070
          </p>
        </div>
        <div className="analysis-stat">
          <span>COMPARISON RMSE</span>
          <strong>
            {number(pair.rmse)}
            <small> mm</small>
          </strong>
          <p>Validation failed · {pair.count} comparisons</p>
        </div>
        <div className="analysis-stat">
          <span>ACCEPTED RESEARCH PIXELS</span>
          <strong>{pair.accepted.toLocaleString()}</strong>
          <p>Interpolation sensitivity mask</p>
        </div>
        <div className="analysis-stat">
          <span>TOTAL UNCERTAINTY</span>
          <strong className="unknown">Unknown</strong>
          <p>Independent calibration required</p>
        </div>
      </section>
      <div className="analysis-toolbar">
        <div className="segmented">
          <button
            className={layer === "coherence" ? "active" : ""}
            onClick={() => setLayer("coherence")}
          >
            Radar coherence
          </button>
          <button
            className={layer === "los" ? "active" : ""}
            onClick={() => setLayer("los")}
          >
            Provisional LOS · mm
          </button>
        </div>
        <div className="analysis-timeline">
          {research.pairs.map((p) => (
            <button
              key={p.id}
              className={pairId === p.id ? "active" : ""}
              onClick={() => {
                setPlaying(false);
                setPairId(p.id);
                setPixel(undefined);
              }}
            >
              <span>PAIR 0{p.id + 1}</span>
              {p.before.slice(5)} → {p.after.slice(5)}
            </button>
          ))}
          <button
            onClick={() => setPlaying(!playing)}
            aria-label={
              playing
                ? "Pause acquisition progression"
                : "Play acquisition progression"
            }
          >
            {playing ? <Pause size={17} /> : <Play size={17} />}
          </button>
        </div>
      </div>
      <section className="analysis-map">
        <Suspense fallback={<Skeleton label="Preparing spatial analysis…" />}>
          <MapViewer
            pair={pair}
            layer={layer}
            selection={{ name: "California research AOI", bbox: CALIFORNIA }}
            onPixel={setPixel}
            onStation={(s: Station) => setStation(s.station)}
            quality={quality}
          />
        </Suspense>
        {pixel && (
          <div className="pixel-card">
            <span>ACCEPTED DISPLAY-CELL MEAN</span>
            <strong>
              {layer === "los" ? signed(pixel.los) : number(pixel.coherence, 3)}
              <small>{layer === "los" ? " mm" : " coherence"}</small>
            </strong>
            <p>
              {pixel.latitude.toFixed(5)}°, {pixel.longitude.toFixed(5)}°
            </p>
            <small>
              {layer === "los" ? pixel.losSupport : pixel.support} accepted
              source pixels · {pair.before} → {pair.after}
            </small>
            <p className="tiny">Total uncertainty unknown · reference P287</p>
          </div>
        )}
      </section>
      <div className="analysis-under-map">
        <label>
          Display-cell mean coherence ≥ <strong>{quality.toFixed(2)}</strong>
          <input
            type="range"
            min="0"
            max="1"
            step=".05"
            value={quality}
            onChange={(e) => setQuality(+e.target.value)}
            aria-label="Analysis display-cell coherence filter"
          />
        </label>
        <span>
          Higher coherence does not establish reliable ground displacement.
        </span>
      </div>
      <section className="comparison-section">
        <div className="section-heading">
          <div>
            <div className="eyebrow">
              <span />
              TIME, SIDE BY SIDE
            </div>
            <h2>Watch the evidence change.</h2>
          </div>
          <div className="mode-tabs">
            {(
              [
                ["swipe", ArrowLeftRight, "Swipe"],
                ["side", Columns2, "Side by side"],
                ["difference", Layers, "Difference"],
                ["temporal", ChartNoAxesCombined, "Temporal graph"],
              ] as const
            ).map(([key, Icon, label]) => (
              <button
                key={key}
                className={mode === key ? "active" : ""}
                onClick={() => setMode(key)}
              >
                <Icon size={15} />
                {label}
              </button>
            ))}
          </div>
        </div>
        <p className="section-description">
          Compare two interferograms covering the same area. Each panel
          represents a 12-day acquisition pair, not an individual optical image.
          The difference mode is restricted to coherence on common native-pixel
          support.
        </p>
        {mode === "swipe" && (
          <div className="swipe-comparison">
            <div className="swipe-base">
              <Raster pair={research.pairs[1]} layer={layer} />
            </div>
            <div
              className="swipe-before"
              style={{ clipPath: `inset(0 ${100 - swipe}% 0 0)` }}
            >
              <Raster pair={research.pairs[0]} layer={layer} />
            </div>
            <div className="swipe-line" style={{ left: `${swipe}%` }}>
              <span>
                <ArrowLeftRight size={18} />
              </span>
            </div>
            <span className="comparison-date left">JUN 29 → JUL 11</span>
            <span className="comparison-date right">JUL 11 → JUL 23</span>
            <input
              aria-label="Acquisition comparison swipe"
              type="range"
              min="0"
              max="100"
              value={swipe}
              onChange={(e) => setSwipe(+e.target.value)}
            />
            <div className="swipe-description">
              Drag to compare · registered Web Mercator display grid ·{" "}
              {layer === "los"
                ? "provisional LOS candidate in mm"
                : "coherence, dimensionless"}
            </div>
          </div>
        )}
        {mode === "side" && (
          <div className="side-comparison">
            {research.pairs.map((p) => (
              <div key={p.id}>
                <div className="comparison-raster">
                  <Raster pair={p} layer={layer} />
                </div>
                <h3>
                  {p.before} → {p.after}
                </h3>
                <p>
                  Pair 0{p.id + 1} ·{" "}
                  {layer === "los"
                    ? "LOS candidate · mm"
                    : "Coherence · dimensionless"}
                  <br />
                  GNSS RMSE {number(p.rmse)} mm · validation failed
                </p>
              </div>
            ))}
          </div>
        )}
        {mode === "difference" && (
          <div className="difference-comparison">
            <div className="comparison-raster">
              <Raster pair={pair} layer="difference" />
            </div>
            <div>
              <Legend layer="difference" />
              <h3>Signal quality changed.</h3>
              <p>{research.difference_note}</p>
              <dl>
                <dt>Mean display-cell difference</dt>
                <dd>{number(stats(pair.difference_values ?? []).mean, 3)}</dd>
                <dt>Display cells with shared support</dt>
                <dd>
                  {stats(pair.difference_values ?? []).count.toLocaleString()}
                </dd>
              </dl>
              <p className="warning">
                Changes in coherence do not identify flooding, earthquakes or a
                physical cause by themselves.
              </p>
            </div>
          </div>
        )}
        {mode === "temporal" && (
          <div className="temporal-view">
            <label>
              GNSS station
              <select
                value={station}
                onChange={(e) => setStation(e.target.value)}
              >
                {pair.stations
                  .filter(
                    (s) =>
                      s.role !== "reference" &&
                      s.relative_nisar_candidate_los_mm != null,
                  )
                  .map((s) => (
                    <option key={s.station}>{s.station}</option>
                  ))}
              </select>
            </label>
            <TemporalChart pairs={research.pairs} station={station} />
          </div>
        )}
        {mode !== "difference" && mode !== "temporal" && (
          <Legend layer={layer} />
        )}
        <p className="tiny">
          Animated progression switches between actual available observations.
          No intermediate scientific measurements are synthesized.
        </p>
      </section>
      <section className="validation-section">
        <div className="section-heading">
          <div>
            <div className="eyebrow">
              <span />
              INDEPENDENT EVIDENCE
            </div>
            <h2>Confidence comes from comparison.</h2>
          </div>
          <span className="failure-badge">VALIDATION FAILED</span>
        </div>
        <div className="validation-grid">
          <ResidualChart pair={pair} />
          <div className="validation-explanation">
            <h3>
              A radar candidate is a question.
              <br />
              GNSS helps test it.
            </h3>
            <p>
              Daily GNSS east, north and up changes are projected into the local
              target-to-sensor line of sight. Radar and GNSS use the same
              acquisition days and the measured P287 reference change.
            </p>
            <div className="validation-numbers">
              <div>
                <span>PAIR 01 · RMSE</span>
                <strong>
                  28.4<small> mm</small>
                </strong>
              </div>
              <div>
                <span>PAIR 02 · RMSE</span>
                <strong>
                  51.1<small> mm</small>
                </strong>
              </div>
            </div>
            <p>
              Both comparisons retain substantial unresolved discrepancies. The
              total uncertainty model and reference stability are unverified.
              Spatial agreement alone does not certify accuracy.
            </p>
            <Link to="/discoveries#california" className="text-button">
              Read the full Earth Story
              <ArrowRight size={15} />
            </Link>
            <SourceLink href={research.gnss_source}>
              Independent GNSS source · NGL
            </SourceLink>
          </div>
        </div>
      </section>
      <section className="method-note">
        <div className="eyebrow">
          <span />
          REPRODUCIBLE, WITH LIMITS
        </div>
        <h3>Know what each number represents.</h3>
        <p>
          Raster inspection uses means of accepted native-pixel centers grouped
          into a 256 × 256 Web Mercator display grid. Regional summary values
          here describe display cells; source-level statistics below describe
          actual native accepted pixels. The LOS map includes only the
          reference-connected component and the prescribed P287 phase median.
          Toward-sensor motion is positive; no conversion to vertical motion is
          made.
        </p>
        <div className="native-stats">
          <div>
            <span>NATIVE MEAN COHERENCE</span>
            <strong>{number(pair.statistics?.coherence.mean, 3)}</strong>
          </div>
          <div>
            <span>NATIVE MEDIAN LOS CANDIDATE</span>
            <strong>{signed(pair.statistics?.los.median)} mm</strong>
          </div>
          <div>
            <span>NATIVE LOS SUPPORT</span>
            <strong>{pair.statistics?.los.count.toLocaleString()}</strong>
          </div>
          <div>
            <span>DISPLAY GRID</span>
            <strong>256 × 256</strong>
          </div>
        </div>
        <code className="granule-id">{pair.granule}</code>
        <Link to="/data" className="text-button">
          Inspect processing and provenance
          <ArrowRight size={15} />
        </Link>
      </section>
    </main>
  );
}
