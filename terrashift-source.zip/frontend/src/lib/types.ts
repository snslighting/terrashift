export type BBox = [number, number, number, number];
export type Position = [number, number];
export type Layer = "coherence" | "los" | "difference";
export type Status =
  | "measured_validated"
  | "measured_provisional"
  | "quality_limited"
  | "no_suitable_data"
  | "processing_unavailable";
export interface Station {
  station: string;
  role: string;
  longitude?: number;
  latitude?: number;
  median_coherence?: number;
  accepted_within_500m?: number;
  relative_nisar_candidate_los_mm?: number;
  relative_gnss_los_mm?: number;
  residual_mm?: number;
  gnss_los_mm?: number;
  gnss_formal_sigma_mm?: number;
  relative_gnss_formal_sigma_mm?: number;
  ionospheric_phase_uncertainty_equivalent_mm?: number;
  unavailable_reason?: string;
  median_phase_rad?: number;
  component?: number;
}
export interface Grid {
  size: number;
  bounds_mercator: BBox;
  values: (number | null)[];
  los_values?: (number | null)[];
  support_counts?: number[];
  los_support_counts?: number[];
  common_support_counts?: number[];
}
export interface Pair {
  id: number;
  before: string;
  after: string;
  granule: string;
  bbox: BBox;
  count: number;
  rmse: number;
  accepted: number;
  threshold: number;
  stations: Station[];
  image: string;
  los_image?: string;
  difference_image?: string;
  difference_values?: (number | null)[];
  coordinates: Position[];
  grid: Grid;
  reference: string;
  science_validated: false;
  total_uncertainty_mm: null;
  epsg?: number;
  wavelength_m?: number;
  reference_phase_rad?: number;
  component?: number;
  metadata?: Record<string, unknown>;
  statistics?: { coherence: Stats; los: Stats };
  source_hashes?: Record<string, string>;
}
export interface Stats {
  count: number;
  mean: number | null;
  median: number | null;
  min: number | null;
  max: number | null;
  p05?: number | null;
  p95?: number | null;
}
export interface Research {
  generated: string;
  pairs: Pair[];
  coherence_note: string;
  gnss_source: string;
  difference_note?: string;
}
export interface Product {
  id: string;
  granule: string;
  collection: string;
  before: string | null;
  after: string | null;
  track: number | null;
  frame: number | null;
  orbit: string | null;
  polarizations: string[];
  geometry: GeoJSON.Geometry | null;
  source_url: string;
  download_auth_required: boolean;
  cached_pair: number | null;
  status: Status;
  metadata_warnings: string[];
}
export interface Discovery {
  products: Product[];
  returned: number;
  hits: number | null;
  bounded: boolean;
  queried_utc: string;
  source: string;
  query: { bbox: BBox; start: string; end: string };
  cached?: boolean;
}
export interface Place {
  name: string;
  longitude: number;
  latitude: number;
  source: string;
}
export interface Selection {
  name: string;
  bbox: BBox;
  polygon?: Position[];
}
export interface Pixel {
  longitude: number;
  latitude: number;
  coherence: number | null;
  los: number | null;
  difference: number | null;
  support: number;
  losSupport: number;
}
