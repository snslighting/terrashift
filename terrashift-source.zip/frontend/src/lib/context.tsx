import { createContext, useContext } from "react";
import type { Research, Selection } from "./types";
export interface AppState {
  research?: Research;
  error: string;
  selection?: Selection;
  setSelection: (s: Selection | undefined) => void;
}
export const AppContext = createContext<AppState>({
  error: "",
  setSelection: () => {},
});
export const useApp = () => useContext(AppContext);
