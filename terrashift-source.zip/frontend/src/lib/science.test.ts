import { describe, expect, it } from "vitest";
import {
  parseCoordinates,
  pointBBox,
  splitBBox,
  stats,
  inspect,
  regionalStats,
  insidePolygon,
} from "./science";
import { color } from "../components/Raster";
import type { Grid } from "./types";

// All fixture values are synthetic and are never included in public research exports.
const grid: Grid = {
  size: 2,
  bounds_mercator: [0, 0, 200, 200],
  values: [0.6, null, 0.9, 0.3],
  los_values: [12, null, -9, 0],
  support_counts: [25, 0, 30, 27],
};
describe("geographic selection and scientific units", () => {
  it("parses latitude, longitude and rejects invalid coordinates", () => {
    expect(parseCoordinates("41.3, 69.24")).toEqual([69.24, 41.3]);
    expect(parseCoordinates("Jakarta")).toBeNull();
    expect(() => parseCoordinates("91, 69")).toThrow();
    expect(splitBBox(pointBBox(179.99, 0))).toHaveLength(2);
    expect(() => splitBBox([0, 0, 1, -1])).toThrow();
  });
  it("preserves missing data, zero and real display support separately", () => {
    const p = inspect(grid, 0.0005, 0.0014);
    expect(p.coherence).toBe(0.6);
    expect(p.los).toBe(12);
    expect(p.support).toBe(25);
    expect(inspect(grid, 20, 20).coherence).toBeNull();
    expect(stats([null, 0, 12, -9]).count).toBe(3);
    expect(stats([null]).mean).toBeNull();
    expect(regionalStats(grid, [-1, -1, 1, 1], "los").count).toBe(3);
  });
  it("clips an AOI by polygon and gives coherent distinct unit palettes", () => {
    expect(
      insidePolygon(
        [0.5, 0.5],
        [
          [0, 0],
          [1, 0],
          [1, 1],
          [0, 1],
          [0, 0],
        ],
      ),
    ).toBe(true);
    expect(
      insidePolygon(
        [2, 2],
        [
          [0, 0],
          [1, 0],
          [1, 1],
          [0, 1],
          [0, 0],
        ],
      ),
    ).toBe(false);
    expect(color(-100, "los")).not.toEqual(color(100, "los"));
    expect(color(0, "difference")).toEqual([247, 247, 247]);
    expect(color(0.5, "coherence")).not.toEqual(color(0.5, "los"));
  });
});
