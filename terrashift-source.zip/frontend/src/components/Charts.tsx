import { motion, useReducedMotion } from "motion/react";
import type { Pair } from "../lib/types";
import { number, finite } from "../lib/science";
export function ResidualChart({ pair }: { pair: Pair }) {
  const reduced = useReducedMotion(),
    rows = pair.stations.filter((s) => finite(s.residual_mm)),
    max = Math.max(100, ...rows.map((s) => Math.abs(s.residual_mm!)));
  return (
    <div className="residual-chart">
      <div className="chart-caption">
        <span>ALL AVAILABLE COMPARISONS</span>
        <span>Residual · mm</span>
      </div>
      {rows.map((s, i) => (
        <div className="bar-row" key={s.station}>
          <span>{s.station}</span>
          <div className="bar-track">
            <i className="zero-line" />
            <motion.i
              className={s.residual_mm! < 0 ? "negative" : "positive"}
              initial={reduced ? false : { width: 0 }}
              animate={{ width: `${(Math.abs(s.residual_mm!) / max) * 48}%` }}
              transition={{ duration: 0.5, delay: i * 0.018 }}
              style={{
                left:
                  s.residual_mm! < 0
                    ? `${50 - (Math.abs(s.residual_mm!) / max) * 48}%`
                    : "50%",
              }}
            />
          </div>
          <strong>{number(s.residual_mm)}</strong>
        </div>
      ))}
      <div className="chart-note">
        Residual = radar candidate − GNSS, both relative to P287. No station was
        removed to improve agreement.
      </div>
    </div>
  );
}
export function TemporalChart({
  pairs,
  station,
}: {
  pairs: Pair[];
  station: string;
}) {
  const values = pairs.map((p) =>
      p.stations.find((s) => s.station === station),
    ),
    limit = Math.max(
      100,
      ...values.flatMap((s) => [
        Math.abs(s?.relative_nisar_candidate_los_mm ?? 0),
        Math.abs(s?.relative_gnss_los_mm ?? 0),
      ]),
    ),
    y = (v: number) => 145 - (v / limit) * 105;
  return (
    <div className="temporal-chart">
      <div className="chart-caption">
        <span>{station} · INDEPENDENT PAIR ESTIMATES</span>
        <span>LOS · mm</span>
      </div>
      <svg
        viewBox="0 0 520 310"
        role="img"
        aria-label={`Radar candidate and GNSS for two acquisition pairs at ${station}. No displacement time-series inversion.`}
      >
        {[-100, -50, 0, 50, 100].map((v) => (
          <g key={v}>
            <line
              x1="58"
              x2="490"
              y1={y(v)}
              y2={y(v)}
              stroke="var(--line)"
              strokeDasharray={v ? "3 6" : undefined}
            />
            <text x="42" y={y(v) + 4} textAnchor="end">
              {v}
            </text>
          </g>
        ))}
        {values.map((s, i) => {
          const x = 175 + i * 195;
          return (
            <g key={i}>
              {finite(s?.relative_nisar_candidate_los_mm) && (
                <>
                  <circle
                    cx={x - 9}
                    cy={y(s!.relative_nisar_candidate_los_mm!)}
                    r="6"
                    fill="#efaa7c"
                  />
                  <text
                    x={x - 9}
                    y={y(s!.relative_nisar_candidate_los_mm!) - 13}
                    textAnchor="middle"
                  >
                    {number(s!.relative_nisar_candidate_los_mm)}
                  </text>
                </>
              )}
              {finite(s?.relative_gnss_los_mm) && (
                <>
                  <circle
                    cx={x + 9}
                    cy={y(s!.relative_gnss_los_mm!)}
                    r="5"
                    fill="#55d9f3"
                  />
                  <text
                    x={x + 9}
                    y={y(s!.relative_gnss_los_mm!) + 22}
                    textAnchor="middle"
                  >
                    {number(s!.relative_gnss_los_mm)}
                  </text>
                </>
              )}
              <text x={x} y="282" textAnchor="middle">
                {pairs[i].before.slice(5)} → {pairs[i].after.slice(5)}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="chart-key">
        <span>
          <i style={{ background: "#efaa7c" }} />
          Radar candidate
        </span>
        <span>
          <i style={{ background: "#55d9f3" }} />
          Independent GNSS
        </span>
      </div>
      <p className="chart-note">
        Two sequential interferograms share July 11. Points are individual pair
        estimates; they do not establish a continuous trend, annual velocity, or
        calibrated time series.
      </p>
    </div>
  );
}
