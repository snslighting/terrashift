import { useEffect, useRef } from "react";
import type { Pair, Layer } from "../lib/types";
import { finite } from "../lib/science";
const viridis = [
  [68, 1, 84],
  [59, 82, 139],
  [33, 145, 140],
  [94, 201, 98],
  [253, 231, 37],
];
const diverge = [
  [33, 102, 172],
  [103, 169, 207],
  [209, 229, 240],
  [247, 247, 247],
  [253, 219, 199],
  [239, 138, 98],
  [178, 24, 43],
];
export function color(value: number, layer: Layer) {
  const t =
    layer === "coherence"
      ? value
      : layer === "los"
        ? (value + 100) / 200
        : value + 0.5;
  const a = layer === "coherence" ? viridis : diverge,
    k = Math.min(1, Math.max(0, t)) * (a.length - 1),
    i = Math.min(a.length - 2, Math.floor(k)),
    f = k - i;
  return a[i].map((v, j) => Math.round(v + (a[i + 1][j] - v) * f));
}
export function paint(
  canvas: HTMLCanvasElement,
  pair: Pair,
  layer: Layer,
  quality = 0,
) {
  const size = pair.grid.size;
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d")!;
  const pixels = context.createImageData(size, size),
    values =
      layer === "coherence"
        ? pair.grid.values
        : layer === "los"
          ? pair.grid.los_values
          : pair.difference_values;
  for (let i = 0; i < size * size; i++) {
    const v = values?.[i];
    if (
      !finite(v) ||
      !finite(pair.grid.values[i]) ||
      pair.grid.values[i]! < quality
    )
      continue;
    const rgb = color(v, layer);
    pixels.data.set([...rgb, 232], i * 4);
  }
  context.putImageData(pixels, 0, 0);
}
export function rasterURL(pair: Pair, layer: Layer, quality = 0) {
  const c = document.createElement("canvas");
  paint(c, pair, layer, quality);
  return c.toDataURL();
}
export function Raster({
  pair,
  layer = "coherence",
  quality = 0,
}: {
  pair: Pair;
  layer?: Layer;
  quality?: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) paint(ref.current, pair, layer, quality);
  }, [pair, layer, quality]);
  return (
    <canvas
      ref={ref}
      className="science-raster"
      aria-label={`${layer === "los" ? "Provisional LOS candidate in millimeters" : layer === "difference" ? "Coherence difference on common native support" : "Radar coherence"} ${pair.before} to ${pair.after}`}
    />
  );
}
export function Legend({ layer }: { layer: Layer }) {
  return (
    <div className="legend">
      <div className="legend-heading">
        {layer === "coherence"
          ? "RADAR COHERENCE"
          : layer === "los"
            ? "PROVISIONAL LOS CANDIDATE"
            : "COHERENCE DIFFERENCE"}
        <span>{layer === "los" ? "mm" : "dimensionless"}</span>
      </div>
      <div
        className={`legend-gradient ${layer === "coherence" ? "sequential" : "diverging"}`}
      />
      <div className="legend-ticks">
        {layer === "coherence" ? (
          <>
            <span>0 · Low</span>
            <span>1 · High</span>
          </>
        ) : (
          <>
            <span>{layer === "los" ? "≤ −100" : "≤ −0.5"}</span>
            <span>0</span>
            <span>{layer === "los" ? "≥ +100" : "≥ +0.5"}</span>
          </>
        )}
      </div>
      <p>
        {layer === "los"
          ? "Toward sensor is positive. Validation failed. Colors saturate at ±100 mm."
          : layer === "difference"
            ? "Pair 02 minus Pair 01 on shared accepted native pixels."
            : "Quality of the radar correspondence. No movement is inferred."}
      </p>
    </div>
  );
}
