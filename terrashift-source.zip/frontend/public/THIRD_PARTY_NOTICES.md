# Third-party notices

MapLibre GL JS: BSD-3-Clause. The MapLibre worker and shared module are redistributed under its license, included in `licenses/maplibre.txt`.

Three.js: MIT, included in `licenses/three.txt`.

React, React DOM, React Router, Motion, Lucide, Vite and supporting dependencies retain their original licenses and source notices. Package versions and dependency provenance are retained in the source distribution's `frontend/package-lock.json`.

Natural Earth country geography is public domain: https://www.naturalearthdata.com/about/terms-of-use/. Source: https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_admin_0_countries.geojson.

Esri World Imagery and World Topo Map are context tile services with on-map attribution. OpenStreetMap context tiles and Photon place search use OpenStreetMap data; https://www.openstreetmap.org/copyright. Context imagery is not a NISAR scientific measurement.

NISAR product metadata/data: NASA / ISRO / ASF. Independent GNSS: Nevada Geodetic Laboratory. Original product identifiers, source links and processing limitations accompany the research export. This project makes no endorsement claim.
